# coding: utf-8

import os


IS_WINDOWS = (os.name == 'nt')
